from flask import Flask, request,url_for,redirect
from flask import render_template
import os
import sqlite3
from flask import g
from flaskr.db import get_db

app = Flask(__name__)

@app.route('/')
def home():
    pg= get_db
    return render_template('home/home.html')