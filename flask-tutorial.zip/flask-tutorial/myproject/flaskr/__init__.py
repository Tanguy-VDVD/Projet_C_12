from flask import Flask, request,url_for,redirect
from flask import render_template
import os
import sqlite3
from flask import g
from flaskr.db import get_db, init_db

app = Flask(__name__)
def result(cours):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    cursor = conn.cursor()
    resu_sub=[]
    failed = 0
    killed = 0
    success = 0
    overflow = 0
    timeout = 0
    crash = 0
    error = 0
    NULL = 0
    for row in cursor.execute("SELECT course, result FROM submissions WHERE course LIKE ?", (cours,)):
        if row[1] == "failed":
            failed +=1
        if row[1] == "killed":
            killed +=1
        if row[1] == "success":
            success +=1
        if row[1] == "overflow":
            overflow +=1
        if row[1] == "timeout":
            timeout +=1
        if row[1] == "crash":
            crash +=1
        if row[1] == "error":
            error +=1
        if row[1] == "NULL":
            NULL +=1  
    resu_sub.append(failed)
    resu_sub.append(killed)
    resu_sub.append(success)
    resu_sub.append(overflow)
    resu_sub.append(timeout)
    resu_sub.append(crash)
    resu_sub.append(error)
    resu_sub.append(NULL)
    conn.close()
    return resu_sub

def reuss_rat(cours):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    pg = conn.cursor()
    stat_sub=[]
    reuss = 0
    rat = 0
    for row in pg.execute("SELECT course, status FROM submissions WHERE course LIKE ?", (cours,)):
        if row[1] == "done":
            reuss +=1
        if row[1] == "error":
            rat +=1
    stat_sub.append(reuss)
    stat_sub.append(rat)
    conn.close()
    return stat_sub

def eleve_task_gr(eleve):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    cursor = conn.cursor()
    task_el=[]
    grade_el=[]
    for row in cursor.execute("SELECT username, task, grade FROM user_tasks WHERE username LIKE ?", (eleve,)):
        task_el.append(row[1])
    conn.close()
    return task_el

def eleve_grade_gr(eleve):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    cursor = conn.cursor()
    task_el=[]
    grade_el=[]
    for row in cursor.execute("SELECT username, task, grade FROM user_tasks WHERE username LIKE ?", (eleve,)):
        grade_el.append(row[2])
    conn.close()
    return grade_el

def eleve_tri(eleve):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    cursor = conn.cursor()
    sub_el=[]
    for row in cursor.execute("SELECT username, task, tried FROM user_tasks WHERE username LIKE ?", (eleve,)):
        sub_el.append(row[2])
    conn.close()
    return sub_el

def couleur(eleve):
    conn = sqlite3.connect(r'C:\Users\Isabelle\inginious.sqlite')
    cursor = conn.cursor()
    sub_el=[]
    for row in cursor.execute("SELECT username, task, tried FROM user_tasks WHERE username LIKE ?", (eleve,)):
        sub_el.append("#ff0000")
    conn.close()
    return sub_el

@app.route('/')
def home():
    return render_template('home/home.html')

@app.route('/cours', methods=['GET', 'POST'])
def cours():
    return render_template('cours/cours.html')

@app.route('/eleves', methods=['GET', 'POST'])
def eleves():
    if request.method == 'POST':
        student = request.form['username']
        error = None

        if not student:
            error = 'Nom d élève requit.'
        student_task_gr = eleve_task_gr(student)
        student_grade_gr = eleve_grade_gr(student)
        student_tri = eleve_tri(student)
        test_coul = couleur(student)
        print(test_coul, student_grade_gr)
        return render_template('home/eleves.html', test_coul=test_coul, student_task_gr=student_task_gr, student_grade_gr=student_grade_gr, student_tri=student_tri)
    return render_template('home/eleves.html')

@app.route('/reussis', methods=['GET', 'POST'])
def reussis():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/reussis.html')

@app.route('/infos', methods=['GET', 'POST'])
def infos():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('home/infos.html')

@app.route('/LSINF1101', methods=['GET', 'POST'])
def LSINF1101():
    stat_sub = reuss_rat('LSINF1101-PYTHON%')
    reuss_null = result('LSINF1101-PYTHON%')
    return render_template('cours/LSINF1101.html', stat_sub=stat_sub, reuss_null=reuss_null)
        

@app.route('/LEPL1402', methods=['GET', 'POST'])
def LEPL1402():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    stat_sub2 = reuss_rat('LEPL1402%')
    reuss_null2 = result('LEPL1402%')
    return render_template('cours/LEPL1402.html', stat_sub2=stat_sub2, reuss_null2=reuss_null2)

@app.route('/LSINF1252', methods=['GET', 'POST'])
def LSINF1252():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    stat_sub3 = reuss_rat('LSINF1252%')
    reuss_null3 = result('LSINF1252%')
    return render_template('cours/LSINF1252.html', stat_sub3=stat_sub3, reuss_null3=reuss_null3)

@app.route('/LINFO1103', methods=['GET', 'POST'])
def LINFO1103():
    if request.method == 'POST':
        return dedirect(url_for('home'))
    return render_template('cours/LINFO1103.html')
