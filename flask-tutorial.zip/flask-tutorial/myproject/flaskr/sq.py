import sqlite3
import os



def reuss_rat(cours):
    conn = sqlite3.connect('inginious.sqlite')
    cursor = conn.cursor()
    stat_sub=[]
    reuss = 0
    rat = 0
    for row in cursor.execute("SELECT course, status FROM submissions WHERE course LIKE ?", (cours,)):
        if row[1] == "done":
            reuss +=1
        if row[1] == "error":
            rat +=1
    stat_sub.append(reuss)
    stat_sub.append(rat)
    conn.close()
    return stat_sub
    

def result(cours):
    resu_sub=[]
    failed = 0
    killed = 0
    success = 0
    overflow = 0
    timeout = 0
    crash = 0
    error = 0
    NULL = 0
    for row in cursor.execute("SELECT course, result FROM submissions WHERE course LIKE ?", (cours,)):
        if row[1] == "failed":
            failed +=1
        if row[1] == "killed":
            killed +=1
        if row[1] == "success":
            success +=1
        if row[1] == "overflow":
            overflow +=1
        if row[1] == "timeout":
            timeout +=1
        if row[1] == "crash":
            crash +=1
        if row[1] == "error":
            error +=1
        if row[1] == "NULL":
            NULL +=1  
    resu_sub.append(failed)
    resu_sub.append(killed)
    resu_sub.append(success)
    resu_sub.append(overflow)
    resu_sub.append(timeout)
    resu_sub.append(crash)
    resu_sub.append(error)
    resu_sub.append(NULL)   
    return resu_sub

